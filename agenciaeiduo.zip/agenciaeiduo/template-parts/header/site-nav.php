<?php if ( has_nav_menu( 'menu_movil', 'menu_escritorio' ) ) : 
  /*Menu UI Mobile 
      wp_nav_menu(array(
          'theme_location'  => 'menu_movil',
          'menu_id'         =>  'mobile-menu',
          'menu_class'      => 'menu'
      ) ); */

  // Menu UI Destock
      wp_nav_menu(array(
          'theme_location'  => 'menu_escritorio',
          'menu_id'         =>  'primary-menu',
          'menu_class'      => 'menu',
          'container'       => 'div',          // Tipo de contenedor
          'container_class' => 'nav--menu'
      ) );

endif; ?>