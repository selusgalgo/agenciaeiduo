<header id="main-header" class="site-header" role="banner">
  <nav id="site-navigation" class="main-navigation" role="navigation">
    <div class="nav--contain">
        <?php 
          //the_custom_logo(); 
          get_template_part('template-parts/header/site-branding');
          get_template_part('template-parts/header/site-nav');
        ?>
        <div class="nav--buttons">
          <a class="h-button" href="/contacto">Contacto</a>
        </div>
        <div class="nav--mobile">
          <button class="menu-button">Menu</button>
        </div>
      </div>
    </nav><!-- #site-navigation -->
</header><!-- #main-header -->