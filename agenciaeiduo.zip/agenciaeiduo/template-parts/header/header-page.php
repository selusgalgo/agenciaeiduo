<?php
$title = get_post_meta(get_the_ID(), 'title', true);
$subtitle = get_post_meta(get_the_ID(), 'subtitle', true);
$image_url = get_post_meta(get_the_ID(), 'image_url', true);
$image_alt = get_post_meta(get_the_ID(), 'image_alt', true);
$image_title = get_post_meta(get_the_ID(), 'image_title', true);
?>
<div class="header-page fullscreen bg-dark nav--light">
    <figure class="wp-block-image size-large">
        <img fetchpriority="hight" decoding="async" src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($image_alt); ?>" title="<?php echo esc_attr($image_title); ?>">
         <div class="gradient-media"></div>
    </figure>
    <div class="content__header">
        <div class="container">
            <div class="row justify-content-space-between align-item-flex-end">
                <div class="w-631 content--title">
                    <h1 class="enfasis medium">Agencia Creativa Digital</h1>
                    <p class="title has-large-font-size"><?php echo esc_html($title); ?></p>
                    <div class="content--boton">
                        <a href="/contacto" class="btn btn--call">Quiero contactar</a>
                        <a href="#quienes-somos" class="btn btn--info">Saber más</a>
                    </div>
                </div>
                <div class="w-364 mt-m content--description">
                    <p class="body medium"><?php echo esc_html($subtitle); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>