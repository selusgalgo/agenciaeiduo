<?php
$bg_color = get_post_meta(get_the_ID(), 'bg_color', true);
$text_color = get_post_meta(get_the_ID(), 'text_color', true);
$image_url = get_post_meta(get_the_ID(), 'image_url', true);
$image_alt = get_post_meta(get_the_ID(), 'image_alt', true);
$image_title = get_post_meta(get_the_ID(), 'image_title', true);
$categories = get_the_terms(get_the_ID(), 'categorias_proyectos'); // Reemplaza 'project_category' con el nombre real de tu taxonomía de categoría de proyecto
$project_tag = get_the_terms(get_the_ID(), 'etiquetas_proyectos'); // Reemplaza 'project_tag' con el nombre real de tu taxonomía de etiqueta de proyecto
?>
<div class="header-entry bg-dark nav--light" style="background-color: <?php echo esc_attr($bg_color); ?>">
    <div class="content__image">
        <?php if ($image_url): ?>
            <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($image_alt); ?>" title="<?php echo esc_attr($image_title); ?>">
        <?php else: ?>
            <?php the_post_thumbnail('full');?>
        <?php endif; ?>
    </div>
    <div class="content__header container <?php echo esc_attr($text_color); ?>">
        <div class="credits">
            <div class="row">
                <div class="col-12 col-md-2">
                <?php
                    if ($project_tag) {
                        echo '<p class="has-small-font-size"><span class="text-color-medium">Cliente: </span>';
                        $last_tag = end($project_tag);
                        foreach ($project_tag as $tag) {
                            echo esc_html($tag->name);
                            if ($tag !== $last_tag) {
                                echo ', ';
                            }
                        }
                        echo '</p>';
                    }
                    ?>
                </div>
                <div class="col-12 col-md-5">
                    <?php
                    if ($categories) {
                        echo '<p class="has-small-font-size"><span class="text-color-medium">Servicio: </span>';
                        $last_category = end($categories);
                        foreach ($categories as $category) {
                            echo esc_html($category->name);
                            if ($category !== $last_category) {
                                echo ', ';
                            }
                        }
                        echo '</p>';
                    }
                    ?>
                </div>
            </div>
        </div>
        <div class="title-entry py-l">
            <div class="row">
                <div class="col-12 col-md-5 col-lg-4">
                    <?php the_title('<h1 class="font-primary light">', '</h1>'); ?>
                </div>
                <div class="col-12 col-md-7 col-lg-7 offset-lg-1">
                    <div class="body"><?php the_excerpt(); ?></div>
                </div>
            </div>
        </div>
    </div>
</div>