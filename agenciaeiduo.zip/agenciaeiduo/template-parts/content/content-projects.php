<ul class="projects row">
    <?php 
        $args = array(
            'post_type' => 'proyectos',
            'post_status' => 'publish',
            'posts_per_page' => 6,
            'orderby' => 'rand'
		);

		$projects_query = new WP_Query($args);
        
        if ( $projects_query->have_posts() ) : while ( $projects_query->have_posts() ) : $projects_query->the_post(); 
        // Obtener las categorías de la publicación
        $categories = get_the_category();
	?>
    
    <li class="project col-12 col-md-4">
            <article class="card-project">
				<?php 
				    // Obtener la URL de la imagen destacada (thumbnail)
				    $thumbnail_url = get_the_post_thumbnail_url();if ( $thumbnail_url ) {
					    // Mostrar la imagen destacada si está disponible
						echo '<img src="' . esc_url( $thumbnail_url ) . '" alt="' . esc_attr( get_the_title() ) . '" />';
					} 
				?>
                <div class="meta-project">
                    <?php
                        // Mostrar título de publicación
                        the_title('<a class="link-item" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><h4 class="font-primary medium">','</h4></a>');
                        // Mostrar las categorías
                        if ( $categories ) {
                            echo '<p>';
                            foreach ( $categories as $category ) {
                                echo '<a class="has-small-font-size text-color-medium" href="' . esc_url( get_category_link( $category->term_id ) ) . '">' . esc_html( $category->name ) . '</a> ';
                            }
                            echo '</p>';
                        }
                    ?>
                </div>
			</article>
	</li>
	<?php endwhile;
        // Restaurar las consultas originales de WordPress
        wp_reset_postdata();
        else :
        // Si no hay publicaciones
        _e( 'No se encontraron proyectos.', 'textdomain' );
	endif; ?>
</ul>