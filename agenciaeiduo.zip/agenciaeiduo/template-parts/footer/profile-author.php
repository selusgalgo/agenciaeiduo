<div class="autor">
	<hr>
	<div class="info_autor pt-5">
		<h3><a class="text-dark link" href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php echo get_the_author_meta( 'display_name'); ?></a></h3>
	</div>
</div>