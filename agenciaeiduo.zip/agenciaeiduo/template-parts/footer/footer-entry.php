<footer class="footer-entry separation-bottom">
	<?php 
		// SHARE-SOCIAL
		get_template_part ( 'template-parts/footer/share-social' );
	?>
	<!--div class="bg-white separation next--case">
		<div class="container text-center">
			<?php

				$next_post = get_next_post();


				/*----- INICIO CUSTOM PHP -----*/

				global $post;
				$parent_caso = $post->post_parent;
				$id_actual = $post->ID;

				$args = array(
				    'post_parent' => $parent_caso,
				    'posts_per_page' => -1,
				    'orderby'   => 'ID',
				    'order' => 'DESC',
    				'post_type' => 'proyectos',
				    );

				$the_query = new WP_Query( $args );

				$nav_casos = array();
				


				if ( $the_query->have_posts() ) :
				while ( $the_query->have_posts() ) : $the_query->the_post();

					array_push( $nav_casos, get_the_ID() );

				endwhile;
				endif;
				
				$long_casos = count($nav_casos);
				
				$position_actual = array_search($id_actual, $nav_casos);
				
				$next = next($nav_casos);

				$this_index = $position_actual + 1;
				$array_moment = $nav_casos[$this_index];



				/*----- FIN CUSTOM PHP -----*/
				if ((!empty($array_moment))): ?>
					<p>Siguiente caso</p>
  					<a class="h2 link text-dark" href="<?php echo esc_url( get_permalink( $array_moment ) ); ?>"><?php echo esc_attr( get_the_title( $array_moment ) ); ?></a>
  				<?php else : ?>
					<p>No hay más proyectos</p>
					<a class="h2 link text-dark" href="/casos">Ver todos los proyectos.</a>
  				<?php endif; ?>
  		</div>
  	</div-->
</footer>