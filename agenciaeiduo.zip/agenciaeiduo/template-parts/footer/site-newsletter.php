<div class="newsletter-footer bg-dark">
    <div class="container">
      <div class="row">

        <div class="col-12 col-md-6">
          <h6 class="has-large-font-size font-primary text-color-gradient-light-1">Newsletter.</h6>
          <p class="body">Suscríbete a nuestra newsletter para estar al día de todas las noticias y novedades, además de nuestros proyectos.</p>
        </div>

        <div class="col-12 col-md-6 col-lg-5 offset-lg-1">
          <div class="newsletter">
            <?php 
              if ( 
                !function_exists('dynamic_sidebar') || !dynamic_sidebar( "Formulario Newsletter") ) : 
              endif; ?>
          </div><!-- .newsletter -->      
        </div><!-- col-12 col-md-4 -->

      </div><!-- .row -->
     </div><!-- .container -->
</div><!-- .newsletter-footer -->
