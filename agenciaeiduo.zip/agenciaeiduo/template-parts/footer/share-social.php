<section class="section--social container-fluid bg-white py-xl">
    <div class="container">
        <?php eiduo_social_share(); ?>
    </div>
</section>