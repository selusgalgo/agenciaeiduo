<?php defined( 'ABSPATH' ) or die( 'No script kiddies please!' ); ?>

<?php get_header();?>

<!-- contenido -->

<?php get_footer();?>