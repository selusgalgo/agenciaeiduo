<?php
// Personalizar el área de administración de WordPress

// Enqueue custom admin styles
function custom_admin_styles() {
    wp_enqueue_style('custom-admin-styles', get_template_directory_uri() . '/assets/css/admin-styles.css');
}
add_action('admin_enqueue_scripts', 'custom_admin_styles');

// Cambiar la URL del logotipo de inicio de sesión
function custom_login_logo_url() {
    return home_url();
}
add_filter('login_headerurl', 'custom_login_logo_url');

// Cambiar el texto del logotipo de inicio de sesión
function custom_login_logo_url_text() {
    return 'Tu Sitio Web';
}
add_filter('login_headertext', 'custom_login_logo_url_text');

// Cambiar el logotipo de inicio de sesión
function custom_login_logo() { ?>
    <style type="text/css">
        .login {
            background:linear-gradient(141deg,#F9F9F9, #FFA350, #FF787E);
        }
        .login h1 a {
            width: auto !important;
            max-width: 180px;
            background-image: url("<?php echo get_stylesheet_directory_uri(); ?>/assets/images/logo.svg") !important;
            background-size: contain !important;
            margin-bottom: 30px;
        }
        .wp-core-ui .button-primary {
            background: #0D0D0D !important;
            border-radius: 0px !important;
            border-color: #0D0D0D !important;
        }
        .login #nav a, .login #backtoblog a {
            color: #0D0D0D !important;
        }
        .privacy-policy-link {
            color: #0D0D0D !important;
        }
    </style>
<?php }
add_action('login_enqueue_scripts', 'custom_login_logo');

// Cambiar el texto del pie de página en el área de administración
function custom_admin_footer_text() {
    echo 'Desarrollado por <a href="https://agenciaeiduo.com" target="_blank">Eiduo.</a>';
}
add_filter('admin_footer_text', 'custom_admin_footer_text');

// Cambiar el logo en la barra de administración
function custom_admin_bar_logo($wp_admin_bar) {
    $args = array(
        'id'    => 'custom_logo',
        'title' => '<img src="' . get_stylesheet_directory_uri() . '/assets/images/logo-admin-bar.svg" style="height: 20px;">',
        'href'  => home_url(),
        'meta'  => array(
            'title' => __('Ir al sitio')
        )
    );
    $wp_admin_bar->add_node($args);
}
add_action('admin_bar_menu', 'custom_admin_bar_logo', 11);

// Personalizar el dashboard
function custom_dashboard_widgets() {
    global $wp_meta_boxes;
    wp_add_dashboard_widget('custom_help_widget', 'Ayuda y Soporte', 'custom_dashboard_help');
}
function custom_dashboard_help() {
    echo '<p>Bienvenido al área de administración. Aquí puedes gestionar tu sitio web.</p>';
}
add_action('wp_dashboard_setup', 'custom_dashboard_widgets');

// Eliminar widgets del dashboard
function remove_dashboard_widgets() {
    global $wp_meta_boxes;
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_activity']); // Actividad
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_quick_press']); // Borrador rápido
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_incoming_links']); // Enlaces entrantes
}
add_action('wp_dashboard_setup', 'remove_dashboard_widgets');
?>
