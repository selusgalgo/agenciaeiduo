<?php
  
  // Campos personalizados de Redes Sociales
  function my_customize_register( $wp_customize ) {
    $wp_customize->add_panel( 'my_custom_options', array(
      'title' => __( 'Personalizar', 'textdomain' ),
      'panel' => 'my_custom_options',
      'priority' => 160,
      'capability' => 'edit_theme_options',
    ));

    // Section para Redes Sociales
    $wp_customize->add_section( 'social_section' , array(
      'title' => __( 'Redes Sociales', 'textdomain' ),
      'panel' => 'my_custom_options',
      'priority' => 2,
      'capability' => 'edit_theme_options',
    ));

    //Redes Sociales: Facebook
    $wp_customize->add_setting( 'my_facebook_url', array(
      'type' => 'option',
      'capability' => 'edit_theme_options',
    ));

    $wp_customize->add_control('my_facebook_url', array(
      'label' => __( 'Facebook URL', 'textdomain' ),
      'section' => 'social_section',
      'priority' => 1,
      'type' => 'text',
    ));

    //Redes Sociales: Twitter
    $wp_customize->add_setting( 'my_twitter_url', array(
      'type' => 'option',
      'capability' => 'edit_theme_options',
    ));

    $wp_customize->add_control('my_twitter_url', array(
      'label' => __( 'Twitter URL', 'textdomain' ),
      'section' => 'social_section',
      'priority' => 2,
      'type' => 'text',
    ));

    //Redes Sociales: Linkedin
    $wp_customize->add_setting( 'my_linkedin_url', array(
      'type' => 'option',
      'capability' => 'edit_theme_options',
    ));

    $wp_customize->add_control('my_linkedin_url', array(
      'label' => __( 'LinkedIN URL', 'textdomain' ),
      'section' => 'social_section',
      'priority' => 3,
      'type' => 'text',
    ));

  }
  add_action( 'customize_register', 'my_customize_register' );