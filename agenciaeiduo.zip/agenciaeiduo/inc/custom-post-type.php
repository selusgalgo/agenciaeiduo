<?php
if ( ! function_exists( 'custom_post_type_proyectos' ) ) {

    // Register Custom Post Type
    function custom_post_type_proyectos() {
    
        $labels = array(
            'name'                  => _x( 'Proyectos', 'agenciaeiduo' ),
            'singular_name'         => _x( 'Proyecto', 'agenciaeiduo' ),
            'menu_name'             => __( 'Proyectos', 'agenciaeiduo' ),
            'name_admin_bar'        => __( 'proyectos', 'agenciaeiduo' ),
            'archives'              => __( 'Archivos de proyectos', 'agenciaeiduo' ),
            'attributes'            => __( 'Atributo de proyecto', 'agenciaeiduo' ),
            'parent_item_colon'     => __( 'Proyecto padre:', 'agenciaeiduo' ),
            'all_items'             => __( 'Todos los proyectos', 'agenciaeiduo' ),
            'add_new_item'          => __( 'Añadir nuevo proyecto', 'agenciaeiduo' ),
            'add_new'               => __( 'Agregar nuevo', 'agenciaeiduo' ),
            'new_item'              => __( 'Nuevo proyecto', 'agenciaeiduo' ),
            'edit_item'             => __( 'Editar proyecto', 'agenciaeiduo' ),
            'update_item'           => __( 'Actualizar proyecto', 'agenciaeiduo' ),
            'view_item'             => __( 'Ver proyecto', 'agenciaeiduo' ),
            'view_items'            => __( 'Ver proyectos', 'agenciaeiduo' ),
            'search_items'          => __( 'Buscar proyectos', 'agenciaeiduo' ),
            'not_found'             => __( 'No encontrado', 'agenciaeiduo' ),
            'not_found_in_trash'    => __( 'No encontrado en la papelera', 'agenciaeiduo' ),
            'featured_image'        => __( 'Imagen destacada', 'agenciaeiduo' ),
            'set_featured_image'    => __( 'Editar imagen destacada', 'agenciaeiduo' ),
            'remove_featured_image' => __( 'Eliminar imagen destacada', 'agenciaeiduo' ),
            'use_featured_image'    => __( 'Usar como imagen destacada', 'agenciaeiduo' ),
            'insert_into_item'      => __( 'Insertar en el proyecto', 'agenciaeiduo' ),
            'uploaded_to_this_item' => __( 'Subir al proyecto', 'agenciaeiduo' ),
            'items_list'            => __( 'Listado de proyectos', 'agenciaeiduo' ),
            'items_list_navigation' => __( 'Lista navegable de proyectos', 'agenciaeiduo' ),
            'filter_items_list'     => __( 'Filtrar lista de proyectos', 'agenciaeiduo' ),
        );
    
        $args = array(
            'label'                 => __( 'Proyectos', 'agenciaeiduo' ),
            'description'           => __( 'Entrada de proyectos.', 'agenciaeiduo' ),
            'labels'                => $labels,
            'supports'              => array( 'title', 'editor', 'thumbnail', 'revisions', 'excerpt', 'custom-fields', 'page-attributes', 'post-formats', 'comments' ),
            'hierarchical'          => false,
            'public'                => true,
            'show_ui'               => true,
            'show_in_menu'          => true,
            'show_in_rest'          => true,
            'menu_position'         => 5,
            'menu_icon'             => 'dashicons-block-default',
            'show_in_admin_bar'     => true,
            'show_in_nav_menus'     => true,
            'can_export'            => false,
            'has_archive'           => true,
            'exclude_from_search'   => false,
            'publicly_queryable'    => true,
            'query_var'             => true,
            'capability_type'       => 'page',
            'rewrite'               => array( 'slug' => 'proyectos' )
        );
        register_post_type( 'proyectos', $args );
    }
    add_action( 'init', 'custom_post_type_proyectos' );
}
// Registrar taxonomía personalizada (Categorías)
function categorias_proyectos() {

    $labels = array(
        'name'                       => _x( 'Categorías', 'Taxonomy General Name', 'agenciaeiduo' ),
        'singular_name'              => _x( 'Categoría', 'Taxonomy Singular Name', 'agenciaeiduo' ),
        // ... más labels aquí ...
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
        'rewrite'                    => array( 'slug' => 'categoria-proyecto' )
    );
    register_taxonomy( 'categorias_proyectos', array( 'proyectos' ), $args );

}
add_action( 'init', 'categorias_proyectos', 0 );

// Registrar taxonomía personalizada (Etiquetas)
function etiquetas_proyectos() {

    $labels = array(
        'name'                       => _x( 'Etiquetas', 'Taxonomy General Name', 'agenciaeiduo' ),
        'singular_name'              => _x( 'Etiqueta', 'Taxonomy Singular Name', 'agenciaeiduo' ),
        // ... más labels aquí ...
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => false,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
        'rewrite'                    => array( 'slug' => 'cliente' )
    );
    register_taxonomy( 'etiquetas_proyectos', array( 'proyectos' ), $args );

}
add_action( 'init', 'etiquetas_proyectos', 0 );

// Mostrar proyectos a través de shortcode
function mostrar_proyectos_por_categoria_shortcode($atts) {
    $atts = shortcode_atts(
        array(
            'categoria_slug' => array(),
            'cantidad' => -1,
            'columnas' => 1,
        ),
        $atts,
        'proyectos'
    );

    $args = array(
        'post_type' => 'proyectos',
        'post_status' => 'publish',
        'posts_per_page' => $atts['cantidad'],
    );

    if (!empty($atts['categoria_slug'])) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'categorias_proyectos',
                'field'    => 'slug',
                'terms'    => $atts['categoria_slug'],
                'operator' => 'IN',
            ),
        );
    }

    $proyectos = new WP_Query($args);
    $output = '';
    
    if ($proyectos->have_posts()) {
        $output .= '<ul class="proyectos row col-row-' . $atts['columnas'] . '">';
        while ($proyectos->have_posts()) {
            $proyectos->the_post();
            $permalink = get_permalink(); // Obtener el enlace permanente
            $category_list = array(); // Añadido para restablecer la lista de categorías en cada iteración
            $categories = get_the_terms(get_the_ID(), 'categorias_proyectos');
            if (!empty($categories)) {
                foreach ($categories as $category) { // Modificado para soportar múltiples categorías
                    $category_id = $category->term_id;
                    $category_name = $category->name;
                    $category_link = get_term_link($category_id, 'categorias_proyectos');
                    $category_list[] = '<a href="' . $category_link . '">' . $category_name . '</a>';
                }
            }
            $output .= '<li class="col mb-m proyecto"><article class="post-proyecto">';
            $output .= '<a href="' . $permalink . '"><img src="' . get_the_post_thumbnail_url() . '"></a>'; // Añadir enlace alrededor de la imagen
            $output .= '<div class="meta-proyecto"><a href="' . $permalink . '"><h4 class="font-primary medium">' . get_the_title() . '</h4></a>';
            $output .= '<p class="has-small-font-size text-color-medium">' . implode(' - ', $category_list) . '</p></div>';
            $output .= '</article></li>';
        }
        $output .= '</ul>';
    } else {
        $output .= 'No hay proyectos para mostrar.';
    }
    
    wp_reset_postdata();
    
    return $output;
}
add_shortcode('proyectos', 'mostrar_proyectos_por_categoria_shortcode');

