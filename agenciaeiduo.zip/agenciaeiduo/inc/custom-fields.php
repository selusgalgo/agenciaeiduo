<?php
// Registra campos personalizados en mi POST PROYECTOS
function my_custom_meta_box() {
    add_meta_box(
        'my_meta_box', // ID of the meta box
        'Campos personalizados', // Title of the meta box
        'my_custom_fields', // Callback function
        'post' // Post type
    );
}
add_action('add_meta_boxes', 'my_custom_meta_box');

function my_custom_fields($post) {
    $values = get_post_custom($post->ID);
    $bg_color = isset($values['bg_color']) ? esc_attr($values['bg_color'][0]) : '';
    $text_color = isset($values['text_color']) ? esc_attr($values['text_color'][0]) : '';
    $client = isset($values['client']) ? esc_attr($values['client'][0]) : '';
    $image_url = isset($values['image_url']) ? esc_attr($values['image_url'][0]) : '';
    $image_alt = isset($values['image_alt']) ? esc_attr($values['image_alt'][0]) : '';
    $image_title = isset($values['image_title']) ? esc_attr($values['image_title'][0]) : '';
    ?>
    <p>
        <label for="bg_color">Color de fondo: </label>
        <input type="text" name="bg_color" id="bg_color" value="<?php echo $bg_color; ?>" />
    </p>
    <p>
        <label for="text_color">Color del texto: </label>
        <input type="text" name="text_color" id="text_color" value="<?php echo $text_color; ?>" />
    </p>
    <p>
        <label for="client">Cliente: </label>
        <input type="text" name="client" id="client" value="<?php echo $client; ?>" />
    </p>
    <p>
        <label for="image_url">URL de la imagen: </label>
        <input type="text" name="image_url" id="image_url" value="<?php echo $image_url; ?>" />
    </p>
    <p>
        <label for="image_alt">Texto alternativo de la imagen: </label>
        <input type="text" name="image_alt" id="image_alt" value="<?php echo $image_alt; ?>" />
    </p>
    <p>
        <label for="image_title">Título de la imagen: </label>
        <input type="text" name="image_title" id="image_title" value="<?php echo $image_title; ?>" />
    </p>
    <?php
}

function my_save_custom_fields($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    if (isset($_POST['bg_color'])) update_post_meta($post_id, 'bg_color', esc_attr($_POST['bg_color']));
    if (isset($_POST['text_color'])) update_post_meta($post_id, 'text_color', esc_attr($_POST['text_color']));
    if (isset($_POST['client'])) update_post_meta($post_id, 'client', esc_attr($_POST['client']));
    if (isset($_POST['image_url'])) update_post_meta($post_id, 'image_url', esc_attr($_POST['image_url']));
    if (isset($_POST['image_alt'])) update_post_meta($post_id, 'image_alt', esc_attr($_POST['image_alt']));
    if (isset($_POST['image_title'])) update_post_meta($post_id, 'image_title', esc_attr($_POST['image_title']));
}
add_action('save_post', 'my_save_custom_fields');
?>