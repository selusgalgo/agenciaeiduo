<?php 
/*
Template Name: Ancho completo
*/
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
get_header();

?>

<article id="page-full-width" class="w-100">
	<?php the_content(); ?>
</article>

<?php 
	get_footer(); 
?>