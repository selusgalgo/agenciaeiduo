jQuery(document).ready(function($){

  // Cuando se hace clic en un enlace
  $('a').on('click', function(e) {
      var url = $(this).attr('href');  // Obtener la URL del enlace

      if (url.indexOf('#') === 0 || (url.indexOf('#') !== -1 && window.location.href.split('#')[0] === url.split('#')[0])) {
          // El enlace es un ancla dentro de la misma página
          return;
      }

      e.preventDefault();  // Prevenir la acción predeterminada del clic en el enlace
      $('#preloader').css({left: '0'});  // Mostrar el preloader

      setTimeout(function() {
          window.location.href = url;  // Redirigir a la URL del enlace después de 0.5 segundos
      }, 500);
  });

  // Cuando la ventana se carga
  $(window).on('load', function() {
      $('#preloader').animate({left: '100%'}, 800);  // Mover el preloader fuera de la pantalla con una animación
  });

  // Cuando el usuario se desplaza hacia abajo, oculta la barra de navegación. Cuando se desplaza hacia arriba, muestra la barra de navegación
  var prevScrollpos = window.pageYOffset;
  window.onscroll = function() {
      var currentScrollPos = window.pageYOffset;
      if ((prevScrollpos > currentScrollPos) || (currentScrollPos < 20)) {
          document.getElementById("main-header").style.top = "0"; // Mostrar la cabecera
          document.getElementById("main-header").style.opacity = "1"; // Establecer opacidad completa
      } else {
          document.getElementById("main-header").style.top = "-100px"; // Ocultar la cabecera
          document.getElementById("main-header").style.opacity = "0"; // Hacerla invisible
      }
      prevScrollpos = currentScrollPos;
  }

  // Cambia el color del menú según el fondo
  $(window).on("load", function() {
      if($('.site-header').hasClass('has-white-background-color') || $('.site-header').hasClass('bg-light')){
          $('header').addClass('nav--dark'); // Añade clase para fondo oscuro
      } else {
          $('header').removeClass('nav--dark');
          $('header').addClass('nav--light'); // Añade clase para fondo claro
      }
  });

  // Cambia el color de la cabecera según la posición del scroll y el fondo visible
  $(window).scroll(function() {
      if (Array.prototype.some.call($('.bg-dark'), function(element) {
          scrollPosition = $(window).scrollTop();
          elementTop = $(element).offset().top;
          elementBottom = $(element).outerHeight() + elementTop;
          if ((scrollPosition > elementTop && scrollPosition < elementBottom) || (scrollPosition == 0)) {
              return true; // Si el fondo oscuro es visible
          }
          else {
              return false; // Si el fondo claro es visible
          }
      })) {
          if(jQuery('header.nav--dark').length > 0){
              jQuery('header').removeClass('nav--dark'); // Eliminar clase para fondo oscuro
          }
          jQuery('header').addClass('nav--light'); // Añadir clase para fondo claro

      } else {
          if(jQuery('header.nav--light').length > 0){
              jQuery('header').removeClass('nav--light'); // Eliminar clase para fondo claro
          }
          jQuery('header').addClass('nav--dark'); // Añadir clase para fondo oscuro
      }
  });

// Seleccionar elementos
const menuButton = document.querySelector('.menu-button');
const navMenu = document.querySelector('.nav--menu');

if (menuButton && navMenu) {
    // Agregar el listener para el botón
    menuButton.addEventListener('click', function () {
        // Verificar si el menú está oculto o visible
        if (window.innerWidth < 1024) { // Solo afecta pantallas pequeñas
            if (navMenu.style.display === 'flex') {
                navMenu.style.display = 'none'; // Ocultar el menú
                menuButton.textContent = 'Menu'; // Cambiar texto a "Menu"
            } else {
                navMenu.style.display = 'flex'; // Mostrar el menú
                menuButton.textContent = 'Cerrar'; // Cambiar texto a "Cerrar"
            }
        }
    });

    // Actualizar el botón cuando se redimensiona la ventana
    window.addEventListener('resize', function () {
        if (window.innerWidth >= 1024) {
            // En pantallas grandes, aseguramos que el menú esté visible y el botón sea "Menu"
            navMenu.style.display = 'flex';
            menuButton.textContent = 'Menu';
        } else {
            // En pantallas pequeñas, aseguramos que el menú esté oculto inicialmente
            navMenu.style.display = 'none';
            menuButton.textContent = 'Menu';
        }
    });
}
  // Selecciona todos los encabezados con la clase "collapsible"
  document.querySelectorAll('.collapsible').forEach((collapsible) => {
    collapsible.addEventListener('click', function () {
      const parentCollapse = this.parentElement; // El div padre con la clase "collapse"

      // Alterna la clase "active" en el contenedor
      parentCollapse.classList.toggle('active');
    });
  });
  
  // Añade la clase 'slide--proyecto' a cada elemento de la lista de proyectos
  const cod = document.querySelectorAll('ul.slideshow--proyectos li.proyecto');
  for (let i = 0; i < cod.length; i++) {
      cod[i].classList.add('slide--proyecto');
  }

  // Configuración del carrusel con Slick
  $('.slideshow--proyectos').slick({
      autoplay: false, // No reproducir automáticamente
      infinite: true, // Ciclo infinito
      arrows: false, // Sin flechas
      dots: true, // Mostrar puntos de navegación
      slidesToShow: 3, // Número de diapositivas visibles
      responsive: [
          {
              breakpoint: 980, // Configuración para pantallas menores a 980px
              settings: {
                  slidesToShow: 2,
                  slidesToScroll: 2
              }
          },
          {
              breakpoint: 767, // Configuración para pantallas menores a 767px
              settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
              }
          }
      ]
  });

  // Enviar automáticamente el formulario cuando cambia
  const form = $('#gform_7'); // Cambiar 'gform_7' por el ID real de tu formulario completo

  if (form.length) {
      form.on('change', function() {
          form.submit(); // Enviar el formulario automáticamente
      });
  }
    
}); // Fin de jQuery
