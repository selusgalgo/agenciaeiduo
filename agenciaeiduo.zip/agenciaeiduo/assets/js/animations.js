jQuery(document).ready(function ($) {
    var animateElement = function ($element, offset, addClass, removeClass) {
        var scrollTop = $(window).scrollTop();

        if (scrollTop > offset) {
            $element.addClass(addClass).removeClass(removeClass);
        } else {
            $element.addClass(removeClass).removeClass(addClass);
        }
    };
    // Animacion de textos
    var $animascroll = $('.animascroll');
    var containerOffset = $animascroll.offset().top - 450;

    $(window).scroll(function () {
        animateElement($animascroll, containerOffset, 'tracking-in-expand', 'tracking-out-contract');
    });

    var $animascrollDown = $('.animascroll-down');
    var containerOffsetDown = $animascrollDown.offset().top - 510;

    $(window).scroll(function () {
        animateElement($animascrollDown, containerOffsetDown, 'tracking-in-expand', 'tracking-out-contract');
    });

    var $animascrollMid = $('.animascroll-mid');
    var containerOffsetMid = $animascrollMid.offset().top - 580;

    $(window).scroll(function () {
        animateElement($animascrollMid, containerOffsetMid, 'tracking-in-expand', 'tracking-out-contract');
    });

    var $animascrollFooter = $('.animascroll-footer');
    var containerOffsetFooter = $animascrollFooter.offset().top - 600;

    $(window).scroll(function () { 
        animateElement($animascrollFooter, containerOffsetFooter, 'tracking-in-expand', 'tracking-out-contract');
    });

    var $animascrollFooterCard = $('.animascroll-footercard');
    var containerOffsetFooterCard = $animascrollFooterCard.offset().top - 680;

    $(window).scroll(function () {
        animateElement($animascrollFooterCard, containerOffsetFooterCard, 'tracking-in-expand', 'tracking-out-contract');
    });


    // Animacion de imagenes

    var $animaimage = $('.animaimage');
    var imageContainerOffset = $animaimage.offset().top - 450;

    $(window).scroll(function () {
        animateElement($animaimage, imageContainerOffset, 'scale-in-hor-left', 'scale-out-hor-left');
    });

    var $animaimageDown = $('.animaimage-down');
    var imageContainerOffsetDown = $animaimageDown.offset().top - 510;

    $(window).scroll(function () {
        animateElement($animaimageDown, imageContainerOffsetDown, 'scale-in-hor-left', 'scale-out-hor-left');
    });

    var $animaimageMid = $('.animaimage-mid');
    var imageContainerOffsetMid = $animaimageMid.offset().top - 580;

    $(window).scroll(function () {
        animateElement($animaimageMid, imageContainerOffsetMid, 'scale-in-hor-left', 'scale-out-hor-left');
    });

    var $animaimageFooter = $('.animaimage-footer');
    var imageContainerOffsetFooter = $animaimageFooter.offset().top - 600;

    $(window).scroll(function () {
        animateElement($animaimageFooter, imageContainerOffsetFooter, 'scale-in-hor-left', 'scale-out-hor-left');
    });


});